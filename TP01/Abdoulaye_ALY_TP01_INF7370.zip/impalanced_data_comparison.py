import pandas as pd
from sklearn.metrics import roc_auc_score, roc_curve
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import (
    AdaBoostClassifier,
    RandomForestClassifier,
    GradientBoostingClassifier,
    BaggingClassifier,
)
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import (
    f1_score,
    roc_auc_score,
    confusion_matrix,
    classification_report,
    roc_curve,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer

# Définition d'une palette de couleurs personnalisée pour les visualisations
custom_colors = ["#7400ff", "#a788e4", "#d216d2", "#ffb500", "#36c9dd"]


def create_balanced_subset(data_path, output_path, polluter_ratio=0.05):
    """
    Crée un sous-ensemble de données deséquilibré où les pollueurs représentent
    un pourcentage spécifié des utilisateurs légitimes.

    Cette fonction permet de générer un jeu de données déséquilibré contrôlé
    pour des tests de classification binaire.

    Args:
        data_path (str): Chemin vers le fichier de données original au format CSV
        output_path (str): Chemin pour sauvegarder le nouveau sous-ensemble au format CSV
        polluter_ratio (float): Ratio désiré de pollueurs par rapport aux utilisateurs légitimes
                               (par défaut: 0.05, soit 5%)

    Returns:
        None: Le résultat est sauvegardé dans le fichier spécifié par output_path.
    """
    # Chargement des données depuis le fichier CSV
    df = pd.read_csv(data_path)

    # Séparation des utilisateurs légitimes (classe 0) et des pollueurs (classe 1)
    legitimate_users = df[df["Class"] == 0]
    polluters = df[df["Class"] == 1]

    # Calcul du nombre de pollueurs à conserver pour respecter le ratio souhaité
    n_legitimate = len(legitimate_users)
    n_polluters_needed = int(n_legitimate * polluter_ratio)

    # Sélection aléatoire des pollueurs avec une graine fixe pour la reproductibilité
    selected_polluters = polluters.sample(n=n_polluters_needed, random_state=42)

    # Création du nouveau dataset en combinant utilisateurs légitimes et pollueurs sélectionnés
    balanced_df = pd.concat([legitimate_users, selected_polluters])

    # Mélange des données pour éviter tout biais d'ordre
    balanced_df = balanced_df.sample(frac=1, random_state=42).reset_index(drop=True)

    # Sauvegarde du nouveau dataset au format CSV
    balanced_df.to_csv(output_path, index=False)

    # Affichage des statistiques pour vérification
    print(f"Nombre d'utilisateurs légitimes : {len(legitimate_users)}")
    print(f"Nombre de pollueurs : {len(selected_polluters)}")
    print(
        f"Ratio pollueurs/légitimes : {len(selected_polluters)/len(legitimate_users):.3f}"
    )


def feature_selection_and_normalization(df):
    """
    Effectue la préparation des données, incluant le traitement des valeurs manquantes
    et la normalisation des caractéristiques.

    Cette fonction:
    1. Remplace les valeurs infinies par NaN dans le cas ou elle exists
    2. Sépare les caractéristiques (X) de la cible (y)
    3. Divise les données en ensembles d'entraînement et de test
    4. Applique un pipeline de prétraitement (imputation et normalisation)

    Parameters:
        df (pd.DataFrame): DataFrame contenant les données à préparer, avec une colonne 'Class'
                          représentant la variable cible (0 pour utilisateurs légitimes, 1 pour pollueurs)

    Returns:
        tuple: Datasets d'entraînement et de test prétraités (X_train, X_test, y_train, y_test)
    """
    # Remplacer les valeurs infinies par NaN pour permettre leur traitement ultérieur
    df.replace([np.inf, -np.inf], np.nan, inplace=True)

    # Séparation des caractéristiques (X) et de la cible (y)
    X = df.drop("Class", axis=1)
    y = df["Class"]

    # Division des données en ensembles d'entraînement (80%) et de test (20%)
    # avec une graine fixe pour la reproductibilité
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    # Création d'un pipeline de prétraitement avec:
    # 1. Imputation des valeurs manquantes par la médiane
    # 2. Normalisation des données (standardisation)
    pipeline = Pipeline(
        [
            ("impute", SimpleImputer(strategy="median")),
            ("scale", StandardScaler()),
        ]
    )

    # Application du pipeline aux données d'entraînement et de test
    # tout en préservant les noms des colonnes
    X_train = pd.DataFrame(
        columns=X_train.columns, data=pipeline.fit_transform(X_train)
    )
    X_test = pd.DataFrame(columns=X_test.columns, data=pipeline.transform(X_test))

    return X_train, X_test, y_train, y_test


def evaluate_model(model, X_test, y_test):
    """
    Évalue les performances d'un modèle de classification à l'aide de diverses métriques.

    Cette fonction calcule:
    - Le taux de vrais positifs (sensibilité) pour les polluters
    - Le taux de faux positifs (1 - spécificitéa pour les polluters)
    - La F-mesure (moyenne harmonique de la précision et du rappel)
    - L'aire sous la courbe ROC (AUC-ROC)

    Parameters:
        model: Modèle de classification entraîné
        X_test (pd.DataFrame): Caractéristiques de l'ensemble de test
        y_test (pd.Series): Étiquettes réelles de l'ensemble de test(la cible)

    Returns:
        dict: Dictionnaire contenant les métriques d'évaluation calculées
    """
    # Prédiction des classes et des probabilités
    y_pred = model.predict(X_test)
    # Utilisation de predict_proba ou decision_function selon le modèle
    y_pred_proba = (
        model.predict_proba(X_test)[:, 1]
        if hasattr(
            model, "predict_proba"
        )  # dans le cas de model pobabiliste comme naive_bayes
        else model.decision_function(X_test)
    )

    # Calcul des éléments de la matrice de confusion
    tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()

    # Calcul des métriques
    tp_rate = tp / (tp + fn)  # Rappel / Sensibilité
    fp_rate = fp / (fp + tn)  # Taux de faux positifs
    f_measure = f1_score(y_test, y_pred)  # F1-score
    auc = roc_auc_score(y_test, y_pred_proba)  # Aire sous la courbe ROC

    # Retour des métriques dans un dictionnaire
    return {
        "TP Rate pollueurs": tp_rate,
        "FP Rate pollueurs": fp_rate,
        "F-mesure": f_measure,
        "AUC - ROC Score": auc,
    }


def train_and_evaluate_models(X_train, X_test, y_train, y_test):
    """
    Entraîne et évalue plusieurs modèles de classification, puis trace leurs courbes ROC.

    Cette fonction:
    1. Entraîne six modèles de classification différents
    2. Calcule leurs scores AUC-ROC
    3. Trace les courbes ROC pour comparaison visuelle
    4. Évalue chaque modèle avec des métriques supplémentaires

    Parameters:
        X_train (pd.DataFrame): Caractéristiques de l'ensemble d'entraînement
        X_test (pd.DataFrame): Caractéristiques de l'ensemble de test
        y_train (pd.Series): Étiquettes de l'ensemble d'entraînement
        y_test (pd.Series): Étiquettes de l'ensemble de test

    Returns:
        dict: Dictionnaire contenant les résultats d'évaluation pour chaque modèle
    """
    # Définition des modèles à entraîner et évaluer
    models = {
        "Decision Tree": DecisionTreeClassifier(random_state=42),
        "Bagging": BaggingClassifier(),
        "AdaBoost": AdaBoostClassifier(random_state=42),
        "Gradient Boosting": GradientBoostingClassifier(random_state=42),
        "Random Forest": RandomForestClassifier(random_state=42),
        "Naive Bayes": GaussianNB(),
    }

    # Dictionnaires pour stocker les résultats
    results = {}
    roc_auc_scores = {}

    # Création d'une figure pour les courbes ROC
    plt.figure(figsize=(10, 8))

    # Boucle sur chaque modèle pour l'entraînement et l'évaluation
    for name, model in models.items():
        # Entraînement du modèle
        model.fit(X_train, y_train)

        # Prédiction des probabilités pour la classe positive
        y_probs = model.predict_proba(X_test)[:, 1]

        # Calcul du score AUC-ROC
        roc_auc = roc_auc_score(y_test, y_probs)
        roc_auc_scores[name] = roc_auc

        # Calcul des points de la courbe ROC
        fpr, tpr, _ = roc_curve(y_test, y_probs)

        # Tracé de la courbe ROC pour ce modèle
        plt.plot(fpr, tpr, lw=2, label=f"{name} (AUC = {roc_auc:.3f})")

        # Évaluation complète du modèle et stockage des résultats
        results[name] = evaluate_model(model, X_test, y_test)

    # Ajout de la ligne diagonale (performance aléatoire)
    plt.plot([0, 1], [0, 1], color=custom_colors[2], lw=2, linestyle="--")

    # Personnalisation du graphique
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curve Comparison avec 5% de pollueurs")
    plt.legend(loc="lower right")
    # Save the ROC curve plot to a file
    plt.savefig("roc_curve_comparison_imbalanced.png", dpi=300, bbox_inches="tight")
    plt.show()

    # Affichage des scores AUC-ROC pour chaque modèle
    for name, score in roc_auc_scores.items():
        print(f"{name}: AUC - ROC = {score:.3f}")

    return results


def display_results(results):
    """
    Affiche les résultats d'évaluation pour tous les modèles testés.

    Cette fonction présente de manière formatée les différentes métriques
    calculées pour chaque modèle.

    Parameters:
        results (dict): Dictionnaire contenant les résultats pour chaque modèle
                       tel que retourné par train_and_evaluate_models()

    Returns:
        None: Les résultats sont affichés dans la console
    """
    # Parcours des résultats pour chaque modèle
    for model_name, metrics in results.items():
        # Affichage du nom du modèle avec une mise en forme distinctive
        print(f"\n======================={model_name}:====================")
        # Affichage de chaque métrique avec 4 décimales de précision
        for metric_name, value in metrics.items():
            print(f"{metric_name}: {value:.4f}")


def main():
    """
    Fonction principale orchestrant le processus complet d'évaluation des modèles.

    Cette fonction:
    1. Charge les données
    2. Prétraite les données
    3. Entraîne et évalue plusieurs modèles
    4. Affiche les résultats

    Returns:
        None: Les résultats sont affichés via les fonctions appelées
    """
    # Chargement des données depuis le fichier CSV
    df = pd.read_csv("imbalanced_data.csv")

    # Commentaire laissé pour référence future
    # setup_visualization_style()

    # Prétraitement des données
    X_train, X_test, y_train, y_test = feature_selection_and_normalization(df)
    # Affichage des dimensions des ensembles d'entraînement et de test
    print(f"Training set shape: {X_train.shape}")
    print(f"Test set shape: {X_test.shape}")

    # Entraînement et évaluation des modèles
    results = train_and_evaluate_models(X_train, X_test, y_train, y_test)

    # Affichage des résultats détaillés
    display_results(results)


if __name__ == "__main__":
    # Point d'entrée du script
    # Définition des chemins de fichiers pour les données
    input_path = "combine_datasets.csv"
    output_path = "imbalanced_data.csv"

    # Création d'un sous-ensemble équilibré de données
    create_balanced_subset(input_path, output_path)
    # Exécution de la fonction principale
    main()
