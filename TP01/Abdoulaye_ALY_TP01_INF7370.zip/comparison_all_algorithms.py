import pandas as pd
from sklearn.metrics import roc_auc_score, roc_curve
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import (
    AdaBoostClassifier,
    RandomForestClassifier,
    GradientBoostingClassifier,
    BaggingClassifier,
)
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import (
    f1_score,
    roc_auc_score,
    confusion_matrix,
    classification_report,
    roc_curve,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer

# Palette de couleurs personnalisée pour la visualisation
custom_colors = ["#7400ff", "#a788e4", "#d216d2", "#ffb500", "#36c9dd"]


def feature_selection_and_normalization(df):
    """
    Effectue la sélection des caractéristiques et la normalisation sur l'ensemble de données.

    Cette fonction traite les valeurs aberrantes en remplaçant les valeurs infinies par NaN,
    sépare les caractéristiques (X) de la variable cible (y), divise les données en ensembles
    d'entraînement et de test, puis applique une imputation et une normalisation.

    Parameters:
    df : pd.DataFrame
        DataFrame contenant les données à normaliser et l'étiquette de classe.

    Returns:
    tuple
        Ensembles de données d'entraînement et de test traités (X_train, X_test, y_train, y_test).
        - X_train : Caractéristiques d'entraînement normalisées
        - X_test : Caractéristiques de test normalisées
        - y_train : Étiquettes d'entraînement
        - y_test : Étiquettes de test
    """
    # Remplacer les valeurs infinies par NaN
    df.replace([np.inf, -np.inf], np.nan, inplace=True)

    # Séparer les caractéristiques (X) et la cible (y)
    X = df.drop("Class", axis=1)
    y = df["Class"]

    # Diviser les données en ensembles d'entraînement et de test
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    # Créer un pipeline pour imputer les valeurs manquantes et normaliser les données
    pipeline = Pipeline(
        [
            (
                "impute",
                SimpleImputer(strategy="median"),
            ),  # Remplacer les NaN par la médiane
            ("scale", StandardScaler()),  # Normalisation (moyenne=0, écart-type=1)
        ]
    )

    # Appliquer le pipeline aux données d'entraînement et de test
    X_train = pd.DataFrame(
        columns=X_train.columns, data=pipeline.fit_transform(X_train)
    )
    X_test = pd.DataFrame(columns=X_test.columns, data=pipeline.transform(X_test))

    return X_train, X_test, y_train, y_test


def evaluate_model(model, X_test, y_test):
    """
    Évalue les performances du modèle à l'aide de diverses métriques.

    Cette fonction calcule plusieurs métriques d'évaluation importantes pour les
    tâches de classification, notamment le taux de vrais positifs, le taux de faux
    positifs, la F-mesure et le score AUC-ROC.

    Parameters:
    model : estimateur scikit-learn
        Modèle de classification entraîné à évaluer.
    X_test : pd.DataFrame
        Caractéristiques de test pour les prédictions.
    y_test : pd.Series
        Étiquettes réelles pour l'évaluation.

    Returns:
    dict
        Dictionnaire contenant les métriques d'évaluation suivantes:
        - 'TP Rate pollueurs' : Taux de vrais positifs (sensibilité)
        - 'FP Rate pollueurs' : Taux de faux positifs (1 - spécificité)
        - 'F-mesure' : Score F1 (moyenne harmonique de la précision et du rappel)
        - 'AUC - ROC Score' : Aire sous la courbe ROC
    """
    # Générer les prédictions de classe
    y_pred = model.predict(X_test)

    # Obtenir les probabilités de prédiction ou les scores de décision selon le modèle
    y_pred_proba = (
        model.predict_proba(X_test)[:, 1]  # Utiliser les probabilités si disponibles
        if hasattr(model, "predict_proba")
        else model.decision_function(X_test)  # Sinon utiliser la fonction de décision
    )

    # Calculer la matrice de confusion et extraire les valeurs
    tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()

    # Calculer les métriques d'évaluation
    tp_rate = tp / (tp + fn)  # Sensibilité / Rappel
    fp_rate = fp / (fp + tn)  # Taux de faux positifs
    f_measure = f1_score(y_test, y_pred)  # F1-score
    auc = roc_auc_score(y_test, y_pred_proba)  # Score AUC-ROC

    # Retourner les métriques dans un dictionnaire
    return {
        "TP Rate  pollueurs": tp_rate,
        "FP Rate  pollueurs": fp_rate,
        "F-mesure": f_measure,
        "AUC - ROC Score": auc,
    }


def train_and_evaluate_models(X_train, X_test, y_train, y_test):
    """
    Entraîne et évalue plusieurs modèles de classification, puis trace les courbes ROC.

    Cette fonction crée, entraîne et évalue six modèles de classification différents,
    puis génère un graphique comparatif des courbes ROC pour tous les modèles.

    Parameters:
    X_train : pd.DataFrame
        Caractéristiques d'entraînement.
    X_test : pd.DataFrame
        Caractéristiques de test.
    y_train : pd.Series
        Étiquettes d'entraînement.
    y_test : pd.Series
        Étiquettes de test.

    Returns:
    dict
        Dictionnaire contenant les résultats d'évaluation pour chaque modèle.
        Format: {'nom_du_modèle': {'métrique1': valeur1, 'métrique2': valeur2, ...}}
    """
    # Définir les modèles à évaluer
    models = {
        "Decision Tree": DecisionTreeClassifier(random_state=42),
        "Bagging": BaggingClassifier(random_state=42),
        "AdaBoost": AdaBoostClassifier(random_state=42),
        "Gradient Boosting": GradientBoostingClassifier(random_state=42),
        "Random Forest": RandomForestClassifier(random_state=42),
        "Naive Bayes": GaussianNB(),
    }

    # Initialiser les dictionnaires pour stocker les résultats
    results = {}
    roc_auc_scores = {}

    # Créer une figure pour tracer les courbes ROC
    plt.figure(figsize=(10, 8))

    # Pour chaque modèle
    for name, model in models.items():
        # Entraîner le modèle
        model.fit(X_train, y_train)

        # Prédire les probabilités
        y_probs = model.predict_proba(X_test)[:, 1]

        # Calculer le score AUC-ROC
        roc_auc = roc_auc_score(y_test, y_probs)
        roc_auc_scores[name] = roc_auc

        # Calculer la courbe ROC
        fpr, tpr, _ = roc_curve(y_test, y_probs)

        # Tracer la courbe ROC
        plt.plot(fpr, tpr, lw=2, label=f"{name} (AUC = {roc_auc:.3f})")

        # Évaluer le modèle et stocker les résultats
        results[name] = evaluate_model(model, X_test, y_test)

    # Tracer la ligne diagonale de référence (classification aléatoire)
    plt.plot([0, 1], [0, 1], color=custom_colors[2], lw=2, linestyle="--")

    # Personnaliser le graphique
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel("Taux de faux positifs")
    plt.ylabel("Taux de vrais positifs")
    plt.title("Comparaison des courbes ROC")
    plt.legend(loc="lower right")
    # Save the ROC curve plot to a file
    plt.savefig("roc_curve_comparison.png", dpi=300, bbox_inches="tight")
    plt.show()

    # Afficher les scores AUC-ROC pour chaque modèle
    for name, score in roc_auc_scores.items():
        print(f"{name}: AUC - ROC = {score:.3f}")

    return results


def display_results(results):
    """
    Affiche les résultats d'évaluation pour tous les modèles de manière formatée.

    Cette fonction parcourt le dictionnaire de résultats et affiche les métriques
    d'évaluation pour chaque modèle dans un format lisible.

    Parameters:
    results : dict
        Dictionnaire contenant les résultats pour chaque modèle.
        Format: {'nom_du_modèle': {'métrique1': valeur1, 'métrique2': valeur2, ...}}

    Returns:
    None
        Cette fonction affiche les résultats mais ne renvoie aucune valeur.
    """
    for model_name, metrics in results.items():
        print(f"\n======================={model_name}:====================")
        for metric_name, value in metrics.items():
            print(f"{metric_name}: {value:.4f}")


def main():
    """
    Fonction principale pour orchestrer le processus d'évaluation des modèles.

    Cette fonction coordonne l'ensemble du flux de travail:
    1. Charge les données prétraitées du fichier CSV
    2. Effectue la sélection des caractéristiques et la normalisation
    3. Entraîne et évalue plusieurs modèles de classification
    4. Affiche les résultats d'évaluation

    Returns:
    None
        Cette fonction ne renvoie aucune valeur.
    """
    # Charger les données
    df = pd.read_csv("combine_datasets.csv")

    # Configuration du style de visualisation (commenté dans le code original)
    # setup_visualization_style()

    # Prétraiter les données
    X_train, X_test, y_train, y_test = feature_selection_and_normalization(df)
    print(f"Forme de l'ensemble d'entraînement: {X_train.shape}")
    print(f"Forme de l'ensemble de test: {X_test.shape}")

    # Entraîner et évaluer les modèles
    results = train_and_evaluate_models(X_train, X_test, y_train, y_test)

    # Afficher les résultats
    display_results(results)


# Point d'entrée du script
if __name__ == "__main__":
    main()
