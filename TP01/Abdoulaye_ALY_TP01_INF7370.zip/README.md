**Nom** : Balde  
**Prénom** : Abdoulaye  
**Code permanent** : BALA17269605  
**Courriel** : balde.abdoulaye.4@courrier.uqam.ca

**Nom** : Diallo  
**Prénom** : Aly Mourtada  
**Code permanent** : DIAA01369609  
**Courriel** : diallo.aly_mourtada@courrier.uqam.ca

### **Instructions pour exécuter les scripts Python**

#### **Étape 1 : Préparation de l'environnement**

1. **Installer Python** :

   - Vérifiez que Python 3.x est installé sur votre machine avec la commande :
     ```bash
     python --version
     ```

2. **Installer les dépendances** :
   - Ouvrez un terminal ou une invite de commande.
   - Naviguez jusqu'au dossier contenant les scripts et les données.
   - Installez les bibliothèques nécessaires avec la commande :
     ```bash
     pip install pandas scikit-learn matplotlib seaborn numpy
     ```

#### **Étape 2 : Exécution des scripts dans l'ordre**

Exécutez les scripts dans l'ordre suivant :

```bash
python features_extractions.py
python comparison_all_algorithms.py
python imbalanced_data_comparison.py
```

**Remarque** : Les 3 scripts et le dossier `Datasets` contenant les données doivent être dans le même répertoire.

#### **1. Exécuter `features_extractions.py`**

- **Objectif** : Extraire les caractéristiques nécessaires des fichiers de données dans le dossier `Datasets`.
- **Instructions** :
  1. Ouvrez un terminal ou une invite de commande.
  2. Naviguez jusqu'au dossier contenant le script `features_extractions.py` et le dossier `Datasets`.
  3. Exécutez le script avec la commande :
     ```bash
     python features_extractions.py
     ```
  4. Si tout se déroule correctement, les 5 premières lignes du fichier de sortie (`combine_datasets.csv`) seront affichées, et ce fichier sera enregistré dans le même dossier que les scripts.

#### **2. Exécuter `comparison_all_algorithms.py`**

- **Objectif** : Comparer plusieurs algorithmes de classification sur les données extraites.
- **Instructions** :
  1. Assurez-vous que le fichier `combine_datasets.csv` généré par `features_extractions.py` est disponible.
  2. Ouvrez un terminal ou une invite de commande.
  3. Naviguez jusqu'au dossier contenant le script `comparison_all_algorithms.py`.
  4. Exécutez le script avec la commande :
     ```bash
     python comparison_all_algorithms.py
     ```
  5. Le script affichera les résultats de la comparaison des algorithmes, y compris les courbes ROC et les métriques de performance. Cliquez sur la lettre `q` pour fermer les graphiques et afficher les résultats.

---

#### **3. Exécuter `imbalanced_data_comparison.py`**

- **Objectif** : Comparer les performances des modèles sur des données déséquilibrées.
- **Instructions** :
  1. Assurez-vous que le fichier `combine_datasets.csv` généré par `features_extractions.py` est disponible.
  2. Ouvrez un terminal ou une invite de commande.
  3. Naviguez jusqu'au dossier contenant le script `imbalanced_data_comparison.py`.
  4. Exécutez le script avec la commande :
     ```bash
     python imbalanced_data_comparison.py
     ```
  5. Le script affichera les résultats de la comparaison des modèles sur des données déséquilibrées, y compris les courbes ROC et les métriques adaptées.


### **Étape 3 : Vérification des résultats**

- Après l'exécution de chaque script, vérifiez les fichiers de sortie et les graphiques générés.
- Les résultats seront affichés dans la console et/ou sauvegardés dans des fichiers (par exemple, des fichiers CSV ou des images de courbes ROC).


### **Étape 4 : Résolution des erreurs courantes**

- **Erreur : Module non trouvé** :
  - Si un module est manquant, installez-le avec `pip install <nom_du_module>`.
- **Erreur : Fichier de données manquant** :
  - Assurez-vous que les fichiers de données sont dans le bon dossier et que les chemins d'accès dans les scripts sont corrects.
- **Erreur : Données non prétraitées** :
  - Vérifiez que `features_extractions.py` a bien été exécuté avant les autres scripts.


### **Résumé des commandes**

1. Installer les dépendances :
   ```bash
   pip install pandas scikit-learn matplotlib seaborn numpy
   ```
2. Exécuter les scripts dans l'ordre :
   ```bash
   python features_extractions.py
   python comparison_all_algorithms.py
   python imbalanced_data_comparison.py
   ```

En suivant ces étapes, vous devriez pouvoir exécuter les scripts sans erreur et obtenir les résultats attendus.
