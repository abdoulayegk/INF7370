import pandas as pd
import numpy as np
import re
import warnings

# Ignorer les avertissements pour une sortie plus propre
warnings.filterwarnings("ignore")


def load_data(file_paths):
    """
    Charge les ensembles de données à partir des chemins de fichiers fournis.

    Cette fonction lit les fichiers texte tabulaires et les convertit en DataFrames pandas
    avec les noms de colonnes appropriés selon le type de données (profil, abonnements ou tweets).

    Parameters:
    file_paths : dict
        Dictionnaire contenant les noms des fichiers comme clés et les chemins d'accès comme valeurs.
        Format attendu: {'nom_du_dataset': 'Datasets/fichier.txt', ...}

    Returns:
    dict
        Dictionnaire contenant les ensembles de données chargés sous forme de DataFrames pandas.
    """
    datasets = {}
    for name, path in file_paths.items():
        if "profile" in name:
            datasets[name] = pd.read_table(
                path,
                header=None,
                names=[
                    "UserID",
                    "CreatedAt",
                    "CollectedAt",
                    "NumberOfFollowings",
                    "NumberOfFollowers",
                    "NumberOfTweets",
                    "LengthOfScreenName",
                    "LengthOfDescriptionInUserProfile",
                ],
            )
        elif "followings" in name:
            datasets[name] = pd.read_table(
                path,
                header=None,
                names=["UserID", "SeriesOfNumberOfFollowings"],
            )
        elif "tweets" in name:
            datasets[name] = pd.read_table(
                path,
                header=None,
                names=["UserID", "TweetID", "Tweet", "CreatedAt"],
            )
    return datasets


def features_extraction(df):
    """
    Crée de nouvelles caractéristiques pour la détection des comptes suspects.

    Cette fonction enrichit le DataFrame avec des caractéristiques calculées qui peuvent être
    utiles pour distinguer les comptes légitimes des comptes potentiellement malveillants.

    Caractéristiques créées:
    1. FollowingFollowersRatio: Ratio entre le nombre d'abonnements et le nombre d'abonnés
       (ajout de 1 au dénominateur pour éviter la division par zéro)
    2. AccountLifetime: Durée de vie du compte en jours (différence entre CollectedAt et CreatedAt)
    3. AverageTweetsPerDay: Moyenne de tweets par jour(ajout de 1 au denominateur pour eviter la division par zéro qui result au valeurs inf)

    Parameters:
    df : pd.DataFrame
        DataFrame contenant les données de profil des utilisateurs.

    Returns:
    pd.DataFrame
        DataFrame avec les nouvelles caractéristiques ajoutées.
    """
    df["FollowingFollowersRatio"] = df["NumberOfFollowings"] / (
        df["NumberOfFollowers"] + 1
    )
    df["CreatedAt"] = pd.to_datetime(df["CreatedAt"])
    df["CollectedAt"] = pd.to_datetime(df["CollectedAt"])
    df["AccountLifetime"] = (df["CollectedAt"] - df["CreatedAt"]).dt.days
    df["AverageTweetsPerDay"] = df["NumberOfTweets"] / (df["AccountLifetime"] + 1)
    return df


def count_urls(text):
    """
    Compte le nombre d'URLs dans un texte donné à l'aide d'expressions régulières.

    Parameters:
    text : str
        Texte dans lequel les URLs doivent être comptées.

    Returns:
    int
        Nombre d'URLs trouvées dans le texte.
    """
    urls = re.findall(
        r"http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+",
        str(text),
    )
    return len(urls)


def calculate_proportion_url(df):
    """
    Cette fonction calcule la proportion d'URLs dans les tweets et appelle également
    la fonction pour calculer la proportion de mentions '@'.

    Parameters:
    df : pd.DataFrame
        DataFrame contenant les données de tweets.

    Returns:
    pd.DataFrame
        DataFrame avec de nouvelles caractéristiques ajoutées:
        - URL_Count: Nombre d'URLs dans chaque tweet
        - Proportion_URL: Proportion d'URLs par rapport au nombre de tweets
    """
    df["URL_Count"] = df["Tweet"].apply(count_urls)
    df["Proportion_URL"] = df["URL_Count"] / df["Tweet"].notna().astype(int)
    df = calculate_at_proportion(df)
    return df


def calculate_at_proportion(df):
    """
    Calcule la proportion de mentions '@' dans les tweets.

    Cette fonction comptabilise les occurrences du caractère '@' dans chaque tweet
    et calcule leur proportion par rapport à la longueur totale du tweet.

    Parameters:
    df : pd.DataFrame
        DataFrame contenant les données de tweets.

    Returns:
    pd.DataFrame
        DataFrame avec de nouvelles caractéristiques ajoutées:
        - count_AT: Nombre de '@' dans chaque tweet
        - Tweet_Length: Longueur de chaque tweet
        - Proportion_AT: Proportion de '@' par rapport à la longueur du tweet
    """
    df["Tweet"] = df["Tweet"].astype(str)
    df["count_AT"] = df["Tweet"].apply(lambda x: x.count("@"))
    df["Tweet_Length"] = df["Tweet"].apply(len)
    df["Proportion_AT"] = df.apply(
        lambda row: (
            row["count_AT"] / row["Tweet_Length"] if row["Tweet_Length"] != 0 else 0
        ),
        axis=1,
    )
    return df


def calculate_time_diff(df):
    """
    Calcule les différences de temps entre les tweets consécutifs d'un même utilisateur.

    Cette fonction trie les tweets par utilisateur et date de création, puis calcule
    les différences de temps entre tweets consécutifs. Elle génère ensuite des statistiques
    agrégées par utilisateur.

    Parameters:
    df : pd.DataFrame
        DataFrame contenant les données de tweets avec date et heure de création.

    Returns:

    pd.DataFrame
        DataFrame contenant pour chaque utilisateur:
        - Mean_Time_Between_Tweets: Temps moyen entre tweets consécutifs (en secondes)
        - Max_Time_Between_Tweets: Temps maximum entre tweets consécutifs (en secondes)
        - time_difference_between_tweets: Différence entre temps moyen et temps maximum
    """
    df["CreatedAt"] = pd.to_datetime(df["CreatedAt"])
    df = df.sort_values(by=["UserID", "CreatedAt"])
    df["Time_Diff"] = df.groupby("UserID")["CreatedAt"].diff()
    df["Time_Diff_Seconds"] = df["Time_Diff"].dt.total_seconds()
    time_stats = (
        df.groupby("UserID")["Time_Diff_Seconds"].agg(["mean", "max"]).reset_index()
    )
    time_stats.columns = [
        "UserID",
        "Mean_Time_Between_Tweets",
        "Max_Time_Between_Tweets",
    ]
    # Calcule la différence entre le temps moyen et le temps maximum entre deux tweets consécutifs
    time_stats["time_difference_between_tweets"] = (
        time_stats["Mean_Time_Between_Tweets"] - time_stats["Max_Time_Between_Tweets"]
    )
    return time_stats


def merge_data(profile_df, tweet_df):
    """
    Fusionne les données de profil et de tweets.

    Cette fonction élimine les doublons basés sur l'UserID et conserve la première occurrence
    lorsque le même index apparaît plusieurs fois.

    Parameters:

    profile_df : pd.DataFrame
        DataFrame contenant les données de profil.
    tweet_df : pd.DataFrame
        DataFrame contenant les données de tweets.

    Returns:

    pd.DataFrame
        DataFrame fusionné contenant les données de profil et de tweets sans doublons.
    """
    tweet_df_no_duplicates = tweet_df.drop_duplicates(subset="UserID", keep="first")
    profile_df = profile_df.reset_index(drop=True)
    tweet_df_no_duplicates = tweet_df_no_duplicates.reset_index(drop=True)
    merged_df = pd.concat([profile_df, tweet_df_no_duplicates], axis=1)
    return merged_df


def main():
    """
    Fonction principale qui charge, traite et fusionne les ensembles de données,
    puis enregistre le jeu de données final au format CSV.

    Cette fonction effectue les étapes suivantes:
    1. Définit les chemins d'accès aux fichiers de données
    2. Charge les données depuis ces fichiers
    3. Traite les données de profil en extrayant des caractéristiques
    4. Traite les données de tweets en calculant des proportions d'URLs et de mentions
    5. Calcule les différences de temps entre tweets consécutifs
    6. Fusionne les données de profil avec les différences de temps
    7. Fusionne les données de profil et de tweets
    8. Ajoute des étiquettes de classe (1 pour pollueur, 0 pour légitime)
    9. Combine les deux ensembles de données et enregistre le résultat au format CSV

    Note: Les chemins des fichiers doivent être spécifiés comme "Datasets/content_polluters.txt"
    pour que le code produise une sortie.
    """
    # Définit les chemins d'accès pour les ensembles de données
    file_paths = {
        "polluters_profile": "Datasets/content_polluters.txt",
        "polluters_followings": "Datasets/content_polluters_followings.txt",
        "polluters_tweets": "Datasets/content_polluters_tweets.txt",
        "legitimate_profile": "Datasets/legitimate_users.txt",
        "legitimate_followings": "Datasets/legitimate_users_followings.txt",
        "legitimate_tweets": "Datasets/legitimate_users_tweets.txt",
    }

    # Charge les données à partir des chemins d'accès
    data = load_data(file_paths)

    # Traite les données de profil
    data["polluters_profile"] = features_extraction(data["polluters_profile"])
    data["legitimate_profile"] = features_extraction(data["legitimate_profile"])

    # Traite les données de tweets
    data["polluters_tweets"] = calculate_proportion_url(data["polluters_tweets"])
    data["legitimate_tweets"] = calculate_proportion_url(data["legitimate_tweets"])

    # Calcule les différences de temps entre tweets consécutifs
    polluters_time_diff = calculate_time_diff(data["polluters_tweets"])
    legitimate_time_diff = calculate_time_diff(data["legitimate_tweets"])

    # Fusionne les données de profil avec les différences de temps
    data["polluters_profile"] = data["polluters_profile"].merge(
        polluters_time_diff, on="UserID", how="left"
    )
    data["legitimate_profile"] = data["legitimate_profile"].merge(
        legitimate_time_diff, on="UserID", how="left"
    )

    # Fusion finale des données de profil et de tweets
    polluters_final = merge_data(data["polluters_profile"], data["polluters_tweets"])
    legitimate_final = merge_data(data["legitimate_profile"], data["legitimate_tweets"])

    # Ajoute des étiquettes de classe aux ensembles de données
    polluters_final["Class"] = 1  # 1 pour les pollueurs (comptes suspects)
    legitimate_final["Class"] = 0  # 0 pour les utilisateurs légitimes

    # Supprime les colonnes inutiles avant la concaténation
    columns_to_drop = ["UserID", "CreatedAt", "CollectedAt", "TweetID", "Tweet"]
    polluters_final = polluters_final.drop(columns=columns_to_drop)
    legitimate_final = legitimate_final.drop(columns=columns_to_drop)

    # Combine les deux ensembles de données et enregistre au format CSV
    final_df = pd.concat([polluters_final, legitimate_final], axis=0, ignore_index=True)
    final_df.to_csv("combine_datasets.csv", index=False)
    print("The datasets are ready and the name of the file is: combine_datasets.csv")
    print(final_df.head())


if __name__ == "__main__":
    main()
